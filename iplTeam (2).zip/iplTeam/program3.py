import os
import pandas as pd
from flask import Flask, render_template, jsonify, request
import numpy as np
import dill as pickle
from sklearn.externals import joblib
from flask_bootstrap import Bootstrap
player_list2=pd.read_csv("C:\\Users\\Lenovo\\Desktop\\iplTeam\\player_list.csv")


with open("C:/Users/Lenovo/Desktop/iplTeam/models/"+'model_v1.pk' ,'rb') as f:
    clf = pickle.load(f)
    
#clf = 'model_v1.pk'

app = Flask(__name__)

@app.route('/',methods=['GET','POST'])
#def index():
#    if request.method=='POST':
#        teamid=request.form['teamaId']
#        print(teamid)
#    return render_template('index.html')
def index():
#    if request.method=='POST':
#        teamAid=request.form['teamAid']
#        teamAplayer0=request.form['teamAplayer0']
#        teamAplayer1=request.form['teamAplayer1']
#        teamAplayer2=request.form['teamAplayer2']
#        teamAplayer3=request.form['teamAplayer3']
#        teamAplayer4=request.form['teamAplayer4']
#        teamAplayer5=request.form['teamAplayer5']
#        teamAplayer6=request.form['teamAplayer6']
#        teamAplayer7=request.form['teamAplayer7']
#        teamAplayer8=request.form['teamAplayer8']
#        teamAplayer9=request.form['teamAplayer9']
#        teamAplayer10=request.form['teamAplayer10']
#        
#        teamBid=request.form['teamBid']
#        teamBplayer0=request.form['teamBplayer0']
#        teamBplayer1=request.form['teamBplayer1']
#        teamBplayer2=request.form['teamBplayer2']
#        teamBplayer3=request.form['teamBplayer3']
#        teamBplayer4=request.form['teamBplayer4']
#        teamBplayer5=request.form['teamBplayer5']
#        teamBplayer6=request.form['teamBplayer6']
#        teamBplayer7=request.form['teamBplayer7']
#        teamBplayer8=request.form['teamBplayer8']
#        teamBplayer9=request.form['teamBplayer9']
#        teamBplayer10=request.form['teamBplayer10']
         
    return render_template('index.html')



##############################################################################

@app.route('/predict',methods=['GET','POST'])
def predict():
    if request.method=='POST':
            b= []
            m=pd.DataFrame()
#            ma=pd.DataFrame()
            pos=0
            teamAid=int(request.form['teamAid'])
            
            teamAplayer0=int(request.form['teamAplayer0'])
            b.append(teamAplayer0)
            teamAplayer1=int(request.form['teamAplayer1'])
            b.append(teamAplayer1)
            teamAplayer2=int(request.form['teamAplayer2'])
            b.append(teamAplayer2)
            teamAplayer3=int(request.form['teamAplayer3'])
            b.append(teamAplayer3)
            teamAplayer4=int(request.form['teamAplayer4'])
            b.append(teamAplayer4)
            teamAplayer5=int(request.form['teamAplayer5'])
            b.append(teamAplayer5)
            teamAplayer6=int(request.form['teamAplayer6'])
            b.append(teamAplayer6)
            teamAplayer7=int(request.form['teamAplayer7'])
            b.append(teamAplayer7)
            teamAplayer8=int(request.form['teamAplayer8'])
            b.append(teamAplayer8)
            teamAplayer9=int(request.form['teamAplayer9'])
            b.append(teamAplayer9)
            teamAplayer10=int(request.form['teamAplayer10'])
            b.append(teamAplayer10)
            
            teamBid=int(request.form['teamBid'])
            
            teamBplayer0=int(request.form['teamBplayer0'])
            b.append(teamBplayer0)
            teamBplayer1=int(request.form['teamBplayer1'])
            b.append(teamBplayer1)
            teamBplayer2=int(request.form['teamBplayer2'])
            b.append(teamBplayer2)
            teamBplayer3=int(request.form['teamBplayer3'])
            b.append(teamBplayer3)
            teamBplayer4=int(request.form['teamBplayer4'])
            b.append(teamBplayer4)
            teamBplayer5=int(request.form['teamBplayer5'])
            b.append(teamBplayer5)
            teamBplayer6=int(request.form['teamBplayer6'])
            b.append(teamBplayer6)
            teamBplayer7=int(request.form['teamBplayer7'])
            b.append(teamBplayer7)
            teamBplayer8=int(request.form['teamBplayer8'])
            b.append(teamBplayer8)
            teamBplayer9=int(request.form['teamBplayer9'])
            b.append(teamBplayer9)
            teamBplayer10=int(request.form['teamBplayer10'])
            b.append(teamBplayer10)
            for i in range(0,22):
                m=pd.concat([m,player_list2[(player_list2['playerid'] == b[i])]],axis=0)
                m=m.drop(['player'],axis=1)
                ma=pd.DataFrame(m.values.reshape(1, -1))

                
            venue=request.form['stadium']
            toss_winId=request.form['sel_decision']
            tossdecision=request.form['sel_toss']
            home=request.form['hometeam']
            winid=teamAid
            data=pd.DataFrame(columns=('teamid', 'oppid', 'venue', 'toss_winId', 'tossdecision', 'winid','home'))
            data.loc[pos,"teamid"] = teamAid
            data.loc[pos,"oppid"]=teamBid
            data.loc[pos,"venue"]=venue
            data.loc[pos,"toss_winId"]=toss_winId
            data.loc[pos,"tossdecision"]=tossdecision
            data.loc[pos,"winid"]=winid  
            data.loc[pos,"home"]=home
            px=pd.concat([data,ma],axis=1)
            pred=clf.predict(px)
            if(pred[0] == 1):
                predict=("Team A Wins")                
                print(predict)
            else:
                predict=("Team B Wins")
                print(predict)
   
#    return render_template('index.html', predict=(predict))
    return predict 
   
if __name__ == '__main__':
    app.run()
   



