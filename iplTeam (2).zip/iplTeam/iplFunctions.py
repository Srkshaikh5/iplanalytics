import os
from flask import Flask, render_template, json, url_for,request
from flask_bootstrap import Bootstrap
app = Flask(__name__)

@app.route('/',methods=['GET','POST'])
#def index():
#    if request.method=='POST':
#        teamid=request.form['teamaId']
#    return render_template('index.html')
def index():
    if request.method=='POST':
        teamAid=request.form['teamAid']
        teamAplayer0=request.form['teamAplayer0']
        teamAplayer1=request.form['teamAplayer1']
        teamAplayer2=request.form['teamAplayer2']
        teamAplayer3=request.form['teamAplayer3']
        teamAplayer4=request.form['teamAplayer4']
        teamAplayer5=request.form['teamAplayer5']
        teamAplayer6=request.form['teamAplayer6']
        teamAplayer7=request.form['teamAplayer7']
        teamAplayer8=request.form['teamAplayer8']
        teamAplayer9=request.form['teamAplayer9']
        teamAplayer10=request.form['teamAplayer10']
        
        teamBid=request.form['teamBid']
        teamBplayer0=request.form['teamBplayer0']
        teamBplayer1=request.form['teamBplayer1']
        teamBplayer2=request.form['teamBplayer2']
        teamBplayer3=request.form['teamBplayer3']
        teamBplayer4=request.form['teamBplayer4']
        teamBplayer5=request.form['teamBplayer5']
        teamBplayer6=request.form['teamBplayer6']
        teamBplayer7=request.form['teamBplayer7']
        teamBplayer8=request.form['teamBplayer8']
        teamBplayer9=request.form['teamBplayer9']
        teamBplayer10=request.form['teamBplayer10']
         
       
#        print(teamAplayer10)
#        print(teamBplayer10)
#        print(teamBplayer9)
    return render_template('index.html')


@app.route('/predict',methods=['GET','POST'])
#def index():
#    if request.method=='POST':
#        teamid=request.form['teamaId']
#    return render_template('index.html')
def predict():
    if request.method=='POST':
        teamAid=request.form['teamAid']
        teamAplayer0=request.form['teamAplayer0']
        teamAplayer1=request.form['teamAplayer1']
        teamAplayer2=request.form['teamAplayer2']
        teamAplayer3=request.form['teamAplayer3']
        teamAplayer4=request.form['teamAplayer4']
        teamAplayer5=request.form['teamAplayer5']
        teamAplayer6=request.form['teamAplayer6']
        teamAplayer7=request.form['teamAplayer7']
        teamAplayer8=request.form['teamAplayer8']
        teamAplayer9=request.form['teamAplayer9']
        teamAplayer10=request.form['teamAplayer10']
        
        teamBid=request.form['teamBid']
        teamBplayer0=request.form['teamBplayer0']
        teamBplayer1=request.form['teamBplayer1']
        teamBplayer2=request.form['teamBplayer2']
        teamBplayer3=request.form['teamBplayer3']
        teamBplayer4=request.form['teamBplayer4']
        teamBplayer5=request.form['teamBplayer5']
        teamBplayer6=request.form['teamBplayer6']
        teamBplayer7=request.form['teamBplayer7']
        teamBplayer8=request.form['teamBplayer8']
        teamBplayer9=request.form['teamBplayer9']
        teamBplayer10=request.form['teamBplayer10']
        tossdecision=request.form['sel_toss']
        venue=request.form['stadium']
        toss_winId=request.form['sel_decision']
        home=request.form['hometeam']
        
         
       
        print(teamAplayer10)
        print(teamBplayer10)
        print(tossdecision)
        print(venue)
        print(toss_winId)
        print(home)
    return render_template('index.html')
@app.route('/emp')
def emp():
   return render_template('emp.html')
   
if __name__ == '__main__':
    app.run()
   
